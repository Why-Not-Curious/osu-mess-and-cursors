Thank You for downloading this cursor pack :)
All the credits go to creators of those cursors, too many to list them
~Norppis

To use cursor:

1. Copy cursor (xxx).png to your skin folder, if you can't find it, just go
 to osu! options and click "open skin folder"

2. Delete the old cursor.png if theres any

3. Rename the file you copied as cursor.png

To use cursortrail:

1. Copy cursortrail (xxx).png to your skin folder, if you can't find it, just go
 to osu! options and click "open skin folder"

2. Delete the old cursortrail.png if theres any

3. Rename the file you copied as cursortrail.png

NOTICE!!!
If you have cursor@2x.png file in your osu! skin folder, just delete that
one too for guaranteed working, same thing with cursortrail@2x.png